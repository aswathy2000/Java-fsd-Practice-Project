package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.*;

@RestController
public class FeedbackController {

	@Autowired
	FeedbackService feedbackService;

	@Autowired
	FeedbackRepository feedbackRepository;

	@GetMapping(value="/")
	public String showIndexPage(ModelMap model){   
		return "<html>\n"
				+ "<head>\n"
		 		+ "</head>\n"
		 		+ "<body>\n"
		 		+ "<div style=\"text-align: center;\">\n"
		 		+ "<br><br>	<h1>Project - Displaying User Feedback </h1>\n"
		 		+ "		\n"
		 		+ "		<h2 class=\"hello-title\"> User Feedback </h2>\n"
		 		+ "		\n"
		 		+ "		<a href=\"/feedback\">View all feedback</a>\n"
		 		+ "		<br><br>\n"
		 		+ "     <form method=\"get\" action=\"update\">\n"
		 		+ "			<br><h3> Feedback Form:</h3>\n"
		 		+ "			<br><br>User Name: <input type=\"text\" id=\"name\" name=\"name\" placeholder=\"Name \" required>	\n"
		 		+ "			<br><br>Rating: <input type=\"number\" id=\"rating\" name=\"rating\" placeholder=\"Rating \" required>\n"
		 		+ "			<br><br>Comments: <input type=\"text\" id=\"comment\" name=\"comment\" placeholder=\"Comment \" required>\n"
		 		+ "			<br><br><input type=\"submit\" value=\"Submit Feedback\" />\n"
		 		+ "		</form>"
		 		+ "</div>\n"
		 		+ "</body>\n"
		 		+ "</html>";
	}

	@GetMapping("/feedback")
	public @ResponseBody String getAllFeedbacks() {
		// This returns a JSON or XML with the Feedbacks
		Iterable<Feedback> allFB = feedbackRepository.findAll();
		return "<html>\n"
		+ "</head>\n"
		+ "<body>\n"
		+ "<div style=\"text-align: center;\">\n"
		+ "<br><br><h1> View Feedback Table </h1>\n"
		+ allFB.toString()
		+ "</div>\n"
		+ "</body>\n"
		+ "</html>";
	}


}
