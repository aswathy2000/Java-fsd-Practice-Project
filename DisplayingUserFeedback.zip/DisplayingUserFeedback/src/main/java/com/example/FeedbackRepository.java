package com.example;

import org.springframework.data.repository.CrudRepository;

import com.example.*;

public interface FeedbackRepository extends CrudRepository<Feedback, Integer>{

}