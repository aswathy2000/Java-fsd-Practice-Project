$(document).ready(function(){

    $("#proj-list").on('change', function(){
        $(".data").hide();
        $("#"+$(this).val()).fadeIn(700);

    }).change();
    
});

let budget = document.getElementById("PBuget");
let balance = document.getElementById("PBalance");

let updatedBalance = budget-expense;
document.getElementById("PBalance").innerHTML = updatedBalance;

var n = 1;
var x = 1;

let form = document.getElementById("add-exp");

let table = document.getElementById("show");
form.addEventListener("submit", (e)=>{

    e.preventDefault();
    submit();
})

const submit=()=>{

    let vendor = document.getElementById("vendor").value;
    let details = document.getElementById("details").value;
    let expense =  document.getElementById("expense").value;

    let newArray = [vendor, details, expense];

    newArray.forEach((item)=>{
        var NewRow  = table.insertRow(n);
        var cel1 = NewRow.insertCell(0);
        var cel2 = NewRow.insertCell(1);
        var cel3 = NewRow.insertCell(2);

        cel1.innerHTML = list1[x];
        cel2.innerHTML = list2[x];
        cel3.innerHTML = list3[x];
    
        n++;
        x++;
})
form.reset();
}

