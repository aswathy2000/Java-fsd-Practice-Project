create database userInfo;
use userInfo;

drop table user;

create table User(
userID int auto_increment Primary key,
userName varchar(50),
userEmail varchar(50)
);

insert into User (userName,userEmail) values ("Aswathy", "aswathy@email.com"); 
insert into User (userName,userEmail) values ("Kim", "kim@email.com"); 
insert into User (userName,userEmail) values ("Tan", "tan@email.com"); 
insert into User (userName,userEmail) values ("Lee", "lee@email.com"); 
insert into User (userName,userEmail) values ("Annie", "annie@email.com"); 

select * from User;