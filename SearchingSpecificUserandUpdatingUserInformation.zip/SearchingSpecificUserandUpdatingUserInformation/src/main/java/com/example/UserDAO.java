package com.example;

import java.util.List;
import org.springframework.orm.hibernate3.HibernateTemplate;


public class UserDAO {

	private HibernateTemplate temp;

	public void setTemp(HibernateTemplate temp) 
	{
		this.temp = temp;
	}

	//insert
	public int insert(User user) 
	{
		return (int) temp.save(user);
	}


	//retrieve 
	public List<User> getall()
	{
		return (List<User>) temp.find("from User");
	}


	//update -> temp.update 

	public boolean update(User user)
	{
		temp.update(user);
		//return getal();
		return true;
	}

	public List<User> validate(int id)
	{
		//return (User) temp.find("from User where userId=?"+id);

		//get(String entityName, Serializable id)
		
		return (List<User>) temp.find("from User u where u.userId="+id);
	}


}


