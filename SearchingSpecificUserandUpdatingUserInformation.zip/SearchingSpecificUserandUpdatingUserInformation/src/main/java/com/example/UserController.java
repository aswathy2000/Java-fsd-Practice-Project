package com.example;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {
	
	@RequestMapping("/enter")
	public ModelAndView enter(HttpServletRequest request,HttpServletResponse response) 
	{
		ModelAndView mv = new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		
		User user = ac.getBean(User.class);
		UserDAO dao = ac.getBean(UserDAO.class);
		
		int id = Integer.parseInt((request.getParameter("userid")));
		List<User> userList = dao.validate(id);
		if(userList.isEmpty())
		{
			mv.setViewName("fail.jsp");
			mv.addObject("id",id);			
			return mv;
		}
		
		else
		{
			mv.setViewName("update.jsp");
			mv.addObject("id",id);			
			return mv;
		}
	}
	
	@RequestMapping("/update")
	public ModelAndView update(HttpServletRequest request,HttpServletResponse response) 
	{
		ModelAndView mv = new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		
		User user = ac.getBean(User.class);
		UserDAO dao = ac.getBean(UserDAO.class);
		
		int userid = Integer.parseInt((request.getParameter("userid")));
		String username = request.getParameter("name");
		String useremail = request.getParameter("email");
		
		user.setUserId(userid);
		user.setUserName(username);
		user.setUserEmail(useremail);
	
		boolean status = dao.update(user);		
		if(status)
		{
			mv.setViewName("success.jsp");
			return mv;
		}
		else
		{
			mv.setViewName("fail.jsp");
			return mv;
		}
		
		

	}
	
	
	@RequestMapping("/getall")
	public ModelAndView getall(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		
		User user = ac.getBean(User.class);
		UserDAO dao=ac.getBean(UserDAO.class);
		
		List<User> list=dao.getall();
		
		mv.setViewName("display.jsp");
		mv.addObject("userslist",list);
		
		return mv;
	}


}
