package fileHandling;

import java.io.FileWriter;
import java.io.IOException;


public class writeIntoFile {

	public static void main(String[] args) {
		
		

		System.out.println("\n\t Program to write to a File: \n");


		try 
		{
			FileWriter writeToFile = new FileWriter("C://Users//My Pc//Desktop//File.txt");
			writeToFile.write("This a demo to write text into a File!");
			writeToFile.close();
		} 
	
		catch (IOException exeIO) 
		{

			System.out.println("\n\t IO Exception has occurred!!!");
			exeIO.printStackTrace();
		}
		
        
		finally 
		{
			System.out.println("\n\t Text was successfully written to the file - 'File.txt' !!!");
		}
	}

}
