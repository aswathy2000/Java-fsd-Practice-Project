package fileHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class readFile {

	public static void main(String[] args) {
		
		System.out.println("\n\t Program to read from a File: \n");

		try 
		{
			File objFile = new File("C://Users//My Pc//Desktop//File.txt");
			Scanner readFromFile = new Scanner(objFile);
			System.out.println("\n\t Text in File: ");
			while (readFromFile.hasNextLine()) 
			{
				String textStr = readFromFile.nextLine();
				System.out.println("\t" + textStr);
			}
			readFromFile.close();

		} 
		
		catch (FileNotFoundException exe) 
		{
			System.out.println("\n\t File Not Found !!! \n");
			exe.printStackTrace();
		}
		
		finally 
		{
			System.out.println("\n\t Text was successfully read from the file - 'File.txt' !!!");
		}
	}

}
