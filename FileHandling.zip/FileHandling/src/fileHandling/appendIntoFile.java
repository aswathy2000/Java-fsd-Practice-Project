package fileHandling;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class appendIntoFile {

	public static void main(String[] args) {


		System.out.println("\n\t Program to append to a File: \n");


		String filePath = "C://Users//My Pc//Desktop//File.txt";
		String textToAppend = " Demo to Append text to the file - 'File.txt' ";

		try 
		{
			Files.write(Paths.get(filePath), textToAppend.getBytes(), StandardOpenOption.APPEND);
		} 

		catch (IOException exeIO) 
		{
			System.out.println("\n\t IO Exception has occurred!!!");
			exeIO.printStackTrace();
		}

		finally 
		{
			System.out.println("\n\t Text was successfully appended into the file - 'File.txt' !!!");
		}

	}
}
