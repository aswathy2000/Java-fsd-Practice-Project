package validationOfEmailId;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;


public class main {
	
	public static void empEmailPresentorNot(boolean result)
	{
		if (result)
		{
		System.out.println( "\n\t Email-ID present in empEmailId list!!! \n" );
		}
		else
		{
		System.out.println( "\n\t Email-ID not present in empEmailId list!!! \n" );
		}
	}
	
	
	public static void main(String[] args) {
		
		
		System.out.println("\n\t Program to validate if user entered Email-ID present in Employee-EmailId list: \n");


		ArrayList<String> empEmailIdList = new ArrayList<String>();
		empEmailIdList.add("abc101@gmail.com");
		empEmailIdList.add("xyz102@gmail.com");
		empEmailIdList.add("kim103@gmail.com");
		empEmailIdList.add("tan104@gmail.com");
		empEmailIdList.add("annie105@gmail.com");
		empEmailIdList.add("aviso106@gmail.com");
		empEmailIdList.add("park107@gmail.com");
		empEmailIdList.add("lee108@gmail.com");
		empEmailIdList.add("chan109@gmail.com");
		empEmailIdList.add("minhyuk110@gmail.com");
		
		Scanner sc = new Scanner(System.in);

		System.out.println("\n Enter Email-id to search: ");
		String strSearch = sc.next();

		Pattern pattern = Pattern.compile(strSearch);
		
		boolean res = false;
		
		for (String e : empEmailIdList)
		{
			//System.out.println(e);
			if(pattern.matcher(e).matches()==true)
			{
				res = true;
				break;
			}
		}
		
		empEmailPresentorNot(res);
		
	}
}


