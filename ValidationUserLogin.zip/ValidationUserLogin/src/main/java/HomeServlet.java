

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class HomeServlet
 */
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter pw = response.getWriter();

		HttpSession session = request.getSession(false);  
		String username = null;
		String password = null;
		
		pw.println("<html><body>");
		if (session.getAttribute("username") != null && session.getAttribute("password") != null  )
		{
			username =(String)session.getAttribute("username");  
			password =(String)session.getAttribute("password");  
		}
		else 
		{
			pw.println("NULL VALUES ENTERED !!!");
		}
		
		String validUsername = "admin";
		String validPassword = "admin123";
		
		if (username.equals(validUsername) && password.equals(validPassword)  ) 
		{
			pw.println("\n Successful login for Session Username - " + username );
			pw.println("<br><br><br><a href='LogoutServlet'>LOGOUT</a><br>");
		}
		else 
		{
			pw.println("INVALID CREDENTIALS, NOT VALID USERNAME OR PASSWORD ENTERED, TRY AGAIN !!!");
		}
		pw.println("</body></html>");
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
