CREATE DATABASE ecommerceClothing;
USE ecommerceClothing;
CREATE TABLE productClothes(ProductID int primary key auto_increment, brandName varchar(100), typeOfClothing varchar(100), price decimal(10,2));
INSERT INTO productClothes(brandName,typeOfClothing,price) values ( "Gucci", "Jumpsuit", 5000) ;
INSERT INTO productClothes(brandName,typeOfClothing,price) values ( "Chanel", "Dress", 50000) ;
INSERT INTO productClothes(brandName,typeOfClothing,price) values ( "Zara", "Co-ord Set", 3000) ;
INSERT INTO productClothes(brandName,typeOfClothing,price) values ( "H&M", "Trenchcoat", 10000) ;
INSERT INTO productClothes(brandName,typeOfClothing,price) values ( "Levi's", "Jeans", 8000) ;
SELECT * from productClothes;