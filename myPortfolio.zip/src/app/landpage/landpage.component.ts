import { Component } from '@angular/core';

@Component({
  selector: 'app-landpage',
  templateUrl: './landpage.component.html',
  styleUrl: './landpage.component.css'
})
export class LandpageComponent {

}
