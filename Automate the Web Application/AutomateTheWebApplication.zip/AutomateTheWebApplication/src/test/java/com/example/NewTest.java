
package com.example;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.Test;

public class NewTest {

	WebDriver wd=null;


	@BeforeTest
	public void intiate() {
		System.out.println("Config intiated...");
		//register the webdriver =>browser vendor 
		WebDriverManager.chromedriver().setup();
		//creating an object to the object
		wd=new ChromeDriver();
		//maximize the browser
		wd.manage().window().maximize();
	}


	@Test(priority = 1)
	public void Open() throws InterruptedException {

		System.out.println("Open the website link provided...");

		wd.get("https://www.flipkart.com/");
		Thread.sleep(3000);
	}

	@Test(priority = 2)
	public void Registration() throws InterruptedException {

		System.out.println("Registration...");
		
		Thread.sleep(3000);
		wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div/div[2]/div/form/div[4]/a")).click();

		Thread.sleep(3000);
		wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div/div[2]/div/form/div[1]/input")).sendKeys("1234567890");

		Thread.sleep(3000);
		wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div/div[2]/div/form/div[3]/button")).click();

		Thread.sleep(3000);
	}

	@Test(priority = 3)
	public void Login() throws InterruptedException {

		System.out.println("Login...");
		
		Thread.sleep(3000);
		wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div/div[2]/div/form/div[1]/input")).sendKeys("1234567890");

		Thread.sleep(3000);
		wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div/div[2]/div/form/div[3]/button")).click();

		Thread.sleep(3000);
	}

	@Test(priority = 4)
	public void Search() throws InterruptedException {

		System.out.println("Search...");
		wd.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div/div/div/div[1]/div/div[1]/div/div[1]/div[1]/header/div[1]/div[2]/form/div/div/input")).sendKeys("samsung s22");

		Thread.sleep(3000);
		wd.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div/div/div/div[1]/div/div[1]/div/div[1]/div[1]/header/div[1]/div[2]/form/div/button")).click();

		Thread.sleep(3000);

	}

	@Test(priority = 5)
	public void AddToCart() throws InterruptedException {

		System.out.println("AddToCart...");
		
		Thread.sleep(3000);
		
		wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div/div/a/div[2]/div[1]/div[1]")).click();	
	
		Thread.sleep(3000);		
		wd.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[1]/div[1]/div[2]/div/ul/li[1]/button")).click();

		Thread.sleep(3000);
	}
}

