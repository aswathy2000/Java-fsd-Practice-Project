package com.example.demo;

public class UserAuthentication 
{

	public boolean userLogin(String username, String password) 
	{
        return validCredentials(username, password);
    }

    public boolean userLogout(String username) 
    {
        return clearSession(username);
    }


    public boolean validCredentials(String username, String password) 
    {
        return username.equals("username") && password.equals("user1234");
    }

    private boolean clearSession(String username) 
    {
        return username != null && !username.isEmpty();
    }
	
}
