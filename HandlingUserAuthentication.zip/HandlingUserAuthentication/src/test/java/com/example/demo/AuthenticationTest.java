package com.example.demo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AuthenticationTest 
{

	private UserAuthentication userauthentication;

	@BeforeEach
	public void setUpUser() 
	{
		userauthentication = new UserAuthentication();
	}

	@Test
	public void validUserLogin() 
	{
		boolean result = userauthentication.userLogin("username", "user1234");
		assertTrue(result);
	}

	@Test
	public void invalidUserLogin() 
	{
		boolean result = userauthentication.userLogin("invalid", "invalid");
		assertFalse(result);
	}

	@Test
	public void logoutTest() 
	{
		boolean result = userauthentication.userLogout("username");
		assertTrue(result);
	}

	@Test
	public void logoutWithoutUsernameTest() 
	{
		boolean result = userauthentication.userLogout("");
		assertFalse(result);
	}

	@Test
	public void isValidCredentialsTest() 
	{
		boolean result = userauthentication.validCredentials("username", "user1234");
		assertTrue(result);
	}

	@Test
	public void invalidCredentialsTest() 
	{
		boolean result = userauthentication.validCredentials("invalid", "invalid");
		assertFalse(result);
	}
	
	
}