package arithmeticCalculator;

public class divOperation {
	
	int num1, num2;
	double result;
	

	divOperation(int num1, int num2){
		this.num1 =num1;
		this.num2 = num2;
		result = num1/num2;
		System.out.println("\n '/' Division operation is chosen ");
		System.out.println("Result = " + result);
	}
}
