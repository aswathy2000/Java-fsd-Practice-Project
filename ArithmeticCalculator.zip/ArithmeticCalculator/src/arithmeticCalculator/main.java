package arithmeticCalculator;

import java.util.Scanner;

public class main {
	
	static int count=0;
	

	public static void main(String[] args) {
		
		System.out.println("\n\t Arithmetic Calculator: \n\n");
		
		int number1,number2;
		char operator;
		
		final int output=0;
		
		
		char ch = 'y';
		
		do {
			Scanner sc = new Scanner(System.in);
			System.out.println("\n Enter two numbers for calculation: ");
			number1 = sc.nextInt();
			number2 = sc.nextInt();
			
			
			System.out.println("\n Choose operator for calculation: +, -, *, / ");
			operator =sc.next().charAt(0);

			if (operator == '+')
			{
				addOperation objadd = new addOperation(number1, number2);
				
			}
			
			
			else if (operator == '-')
			{

				subOperation objsub = new subOperation(number1, number2);
			
			}

			
			else if (operator == '*')
			{			
				mulOperation objmul = new mulOperation(number1, number2);
				
			}


			else if (operator == '/')
			{
				divOperation objdiv = new divOperation(number1, number2);
				
			}

			else 
			{
				System.out.println("\n Invalid operator!!!");
				System.out.println("\n Result: " + output);

			}
			
			count++;

			System.out.println("\n\n\t Want to do another calculation? (y/n) ");
			ch =sc.next().charAt(0);

		}while(ch!='n');
		
		System.out.println("Number of calculation performed: "+ count);
		
		System.out.println("Done!!!");

	}

}
